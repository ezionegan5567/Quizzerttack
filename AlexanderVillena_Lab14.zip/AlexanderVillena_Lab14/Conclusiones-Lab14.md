# Conclusiones — Laboratorio 14

1. Separar pruebas, respaldo, configuración, módulo y verificación permite detener un despliegue en la fase correcta y ver el costo de cada fase.
2. La simulación demostró que el flujo de publicación se puede inspeccionar sin cambiar el backend; la prueba local inducida se detuvo antes de publicar.
3. Los entornos tienen configuración e índices propios. `BuscarRival` sólo funcionó cuando `nivel_1` y `trofeos_-1` estaban disponibles como índices públicos en development.
4. La verificación económica confirmó que el servidor rechazó la compra sin saldo y no escribió Cloud Save; la búsqueda sin rivales fue una respuesta válida; los tres combates respondieron.
5. Los logs estructurados separan Cloud Save de Remote Config y evitan registrar datos personales de juego. El error deliberado permitió verificar una traza en Cloud Code.
6. La reversión importó el módulo respaldado y confirmó disponibilidad con HoraDelServidor. No revierte datos, índices, políticas ni Remote Config.
7. Las lecturas y escrituras instrumentadas ayudan a estimar consumo. Los tiempos del cliente incluyen red y no equivalen al tiempo facturable de Cloud Code.
8. La validación y reversión se completaron en development. No se realizó despliegue real a production; la entrega a Canvas requiere completar evidencia pendiente y, si el curso lo exige, ejecutar el paso de producción con aprobación.