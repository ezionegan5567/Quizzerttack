# Entrega Lab14 — Quizzerttack

Incluye el módulo Tienda, 72 pruebas, scripts de despliegue/verificación, manifiesto, reversión, planilla de costos, logs de development y el respaldo usado para la reversión.

## Resultado

- Simulación local completada: 72 pruebas y 22,1 s; sin cambios en el backend.
- Despliegue y verificación de development completados el 2026-11-24: 72/72 pruebas; Remote Config, leaderboard, política y módulo actualizados; verificación económica OK; total 72,8 s.
- El primer BuscarRival falló porque development no tenía índices públicos. Se crearon los índices Player/Public nivel_1 y trofeos_-1; la consulta respondió correctamente después.
- La prueba de error deliberado respondió HTTP 422 y produjo trazas en Cloud Code Logs.
- Reversión completada el 2026-11-24: importación, espera de 35 s y HoraDelServidor OK; total 55,9 s.

## Evidencia todavía por completar antes de Canvas

- No se encontró una captura PNG del fallo local 03b; se incluye el log de 71/72 que demuestra que el despliegue se detuvo antes de publicar.
- La captura de roles está parcial; guardar una toma donde se vean completos los roles asignados a Quizzerttack.
- La captura de ForzarErrorPrueba muestra la traza; completar otra toma con el registro Unhandled exception expandido para que se vean tipo y mensaje.
- La guía del curso incluye el paso de producción. No se hizo despliegue real a production; no presentar el paquete como validación de producción.
- Guardar todas las capturas faltantes y reemplazar/añadirlas en `capturas/`, luego volver a comprimir para la entrega final.

Los logs copiados al paquete tienen rutas de usuario/equipo redactadas. No contiene claves de servicio.