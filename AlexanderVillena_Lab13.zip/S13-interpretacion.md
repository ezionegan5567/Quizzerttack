# S13 · Interpretación de la telemetría (Lab13) — QUIZZERTTACK

## 0. Límites de la medición (declara esto en cualquier lectura)
- **Muestra**: UNA sola instalación local (mi editor). No hay jugadores reales.
- **Unidad de conteo**: cada evento es un envío del SDK; los "usuarios" del embudo se agrupan por `ExternalUserId` (`jugador-<n>`), que cambia por sesión — no por instalación permanente.
- **Retención local**: no se guardan datos personales; el identificador se genera en la pantalla de consentimiento y vive solo en el perfil del dispositivo.
- **Analytics ≠ contabilidad**: los eventos de Unity Analytics sirven para ANALIZAR comportamiento; el dinero real (oro/trofeos/bolsa) vive en Cloud Save protegido server-side. Si un evento no llega, el oro no se pierde ni se duplica: la economía es la fuente de verdad del servidor. Sin doble conteo local: los importes que reportan `personaje_comprado` (precio con descuento si hubiese campaña) y `compra_fallida_sin_fondos` (faltante) son los que el SERVIDOR cobró/rechazó, nunca un cálculo del cliente.

## 1. Qué medimos
Con el consentimiento TVYA activado, el juego envía 9 eventos anónimos que cubren el recorrido completo del jugador: arranque (`juego_iniciado`), onboarding (`tutorial_completado`), combate (`primer_combate_iniciado`, `combate_iniciado`, `combate_ganado`, `combate_perdido`) y economía (`tienda_abierta`, `personaje_comprado`, `compra_fallida_sin_fondos`). El ExternalUserId (`jugador-<n>`) agrupa los eventos por perfil sin guardar datos personales.

## 2. Embudo de conversión
`juego_iniciado → tutorial_completado → primer_combate_iniciado → personaje_comprado`

| Escalón | Usuarios | % que avanza |
|---|---|---|
| juego_iniciado | 1 | — |
| tutorial_completado | 1 | 100 % |
| primer_combate_iniciado | 1 | 100 % |
| personaje_comprado | 1 | 100 % |

**Lectura**: con n=1 los porcentajes no dicen nada de retención — dicen que el esquema FUNCIONA: los 4 escalones registraron y el servicio los aceptó (Valid Events subieron, Invalid = 0). Con jugadores reales, la caída esperada estaría entre `juego_iniciado` y `tutorial_completado` (jugadores que no terminan de armar el primer escuadrón).

## 3. Balance de combate (Data Explorer)
Barras de `combate_ganado` vs `combate_perdido` por héroe (`heroe`):

| Héroe | Ganados | Perdidos | % victoria |
|---|---|---|---|
| guerrero_del_hacha | 12 | 0 | 100 % |

**Cruce héroe × rival (obligatorio antes de proponer balance)**: repetir el gráfico agrupando por `heroe` pero comparando por `nivel_rival`:
| Héroe | nivel_rival | Ganados | Perdidos | % victoria |
|---|---|---|---|---|
| guerrero_del_hacha | 1 (NPC Coloso de arena / npc_practica) | 12 | 0 | 100 % |
| guerrero_del_hacha | 19-20 (pvp, pepe) | 1 | 0 | 100 % |

**Lectura (con el cruce ya hecho)**: el 100 % de victoria NO sustenta un cambio de balance: TODAS las victorias fueron contra rivales de nivel 1 (NPC de práctica y Coloso de arena) — el rival es débil, no la carta. El único pvp (vs pepe, nivel 19) también se ganó, pero con n=1 no es evidencia. **No se propone cambio de balance con estos datos**; haría falta una muestra con derrotas reales y rivales de varios niveles. Limitación anotada: no se observó ningún `combate_perdido` en la sesión.
⚠️ Regla: un cambio de balance SOLO se propone si el cruce héroe × nivel_rival lo sostiene. Ganar 100 % contra rivales de nivel 1 no prueba que el héroe esté fuerte — es el rival débil, no la carta.

## 4. Economía (transacciones confirmadas con importes efectivos)
- Compras exitosas: `personaje_comprado` = 1 (Mago, **precio 1200 oro**, saldo final 680). El `precio` reportado es el **precio efectivo cobrado por el servidor** — en esta sesión no había campaña LiveOps activa ("SIN EVENTO"), así que catálogo 1200 = pagado 1200, descuento aplicado=False.
- Fallos por saldo: `compra_fallida_sin_fondos` = 1 registro con `faltante=0` — **dato INVÁLIDO que se anota**: ese intento fue rechazado porque el héroe ya estaba en el inventario ("Ya tenés a Mago"), no por falta de dinero. Corregido en el código: ahora solo se registra el evento cuando `faltante = precio − saldo > 0`. La corrección queda documentada como limitación de la primera medición.
- **Reintentos**: cada intento genera su evento (así se mide la fricción de compra); la "primera pérdida" se distingue por orden temporal — NO se duplica el conteo localmente.
- **Lectura**: precio del catálogo (1200) vs oro de un jugador nuevo → hay fricción de compra real para héroes NO poseídos (faltante ≈ 520 con el saldo post-compra). Con la corrección activa, `compra_fallida_sin_fondos` medirá ese faltante real; si esa métrica >> compras exitosas, tocar precio o recompensas.

## 5. Decisiones que tomaría con estos datos
1. **No tocar balance**: el cruce héroe × nivel_rival no sustenta cambios (solo rivales nivel 1 y n=1).
2. **Medir fricción de compra con la corrección activa**: si `compra_fallida_sin_fondos` (faltante real) supera a `personaje_comprado`, bajar precios del catálogo o subir el oro por combate (+400 oro por victoria NPC hoy).
3. **Instrumentar el onboarding con más granularidad** si con jugadores reales cae el embudo entre `juego_iniciado` y `tutorial_completado` (eventos intermedios de fase de selección).
4. **Repetir la sesión con derrotas** (pvp contra rivales de nivel alto) para poblar `combate_perdido` y poder comparar ganado vs perdido de verdad.

## 6. Limitaciones de la muestra
- Un solo jugador de pruebas (yo) en una sesión corta: los porcentajes NO representan jugadores reales.
- La telemetría solo corre tras ACEPTAR el consentimiento (comportamiento correcto: sin consentimiento, cero recolección).
- Un registro de `compra_fallida_sin_fondos` con `faltante=0` quedó en el dashboard por un caso "héroe ya comprado"; el código ya lo excluye para futuras sesiones.
- `combate_perdido` no se observó: el equipo del jugador domina a los rivales disponibles en la muestra.
